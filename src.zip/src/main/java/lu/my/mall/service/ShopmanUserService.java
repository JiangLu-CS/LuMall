package lu.my.mall.service;

import lu.my.mall.entity.AdminUser;
import lu.my.mall.entity.ShopMan;
import lu.my.mall.util.PageQueryUtil;
import lu.my.mall.util.PageResult;

import java.util.List;

public interface ShopmanUserService {
    ShopMan login(String userName, String password);


    ShopMan getUserDetailById(Integer loginUserId);

    PageResult findShopmanList(PageQueryUtil pageUtil);


    Boolean updatePassword(Integer loginUserId, String originalPassword, String newPassword);

    /**
     * 修改当前登录用户的名称信息
     *
     * @param loginUserId
     * @param loginUserName
     * @param nickName
     * @return
     */
    Boolean updateName(Integer loginUserId, String loginUserName, String nickName);


}
