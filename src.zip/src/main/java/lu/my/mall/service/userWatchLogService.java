package lu.my.mall.service;

import lu.my.mall.util.PageQueryUtil;
import lu.my.mall.util.PageResult;

public interface userWatchLogService {
    void userWatchLog(int time, int userid, int goodsId);

    PageResult findLogList(PageQueryUtil pageUtil);
}
